# Nuevas Mecanicas

Adds three chaotic mechanics to STRAFTAT. Not vanilla compatible.

---

## Crouch Taunts

Crouch for **3 seconds** and your character will start playing random taunt sounds, one at a time, until you stand up. The sounds broadcast to all players in the session.

---

## Explosive Pickups

Every weapon pickup has a **1 in 13** chance of being cursed.

- The weapon turns **red over 0.5 seconds** while a warning sound plays.
- If you're still holding it when the fuse runs out — **you explode**, dealing area damage to nearby players.
- Picking up a different weapon before the fuse expires cancels the explosion.

---

## Z-Mark Teleport

- Press **Z** to place a mark at your current position (shown as a cyan sphere).
- Press **Z again** to teleport back to the mark. The mark is removed.
- Only one mark at a time.
- After teleporting there is a **5-second cooldown** before you can place a new mark.
- Dying removes your mark.

A small HUD label in the bottom-left corner shows the current state at all times.